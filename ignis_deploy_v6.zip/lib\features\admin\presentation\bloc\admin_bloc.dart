import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../data/admin_repository.dart';
import '../../../orders/domain/entities/order.dart';
import '../../../orders/domain/repositories/order_repository.dart';
import '../../../orders/domain/entities/order_status.dart';

// --- Events ---
abstract class AdminEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class AdminLogin extends AdminEvent {}

class LoadAdminData extends AdminEvent {}

class CloseRoomEvent extends AdminEvent {
  final String roomId;
  CloseRoomEvent(this.roomId);
}

class BroadcastMessageEvent extends AdminEvent {
  final String message;
  BroadcastMessageEvent(this.message);
}

class BanUserEvent extends AdminEvent {
  final String userId;
  BanUserEvent(this.userId);
}

class UpdateOrderStatusEvent extends AdminEvent {
  final String orderId;
  final OrderStatus status;
  final String? videoUrl;

  UpdateOrderStatusEvent(this.orderId, this.status, {this.videoUrl});

  @override
  List<Object?> get props => [orderId, status, videoUrl];
}

class AdminLogout extends AdminEvent {}

// --- States ---
abstract class AdminState extends Equatable {
  @override
  List<Object?> get props => [];
}

class AdminInitial extends AdminState {}

class AdminLoading extends AdminState {}

class AdminAuthenticated extends AdminState {
  final Map<String, dynamic> stats;
  final List<dynamic> rooms;
  final List<Order> orders;

  AdminAuthenticated({
    required this.stats,
    required this.rooms,
    required this.orders,
  });

  @override
  List<Object?> get props => [stats, rooms, orders];
}

class AdminError extends AdminState {
  final String message;
  AdminError(this.message);

  @override
  List<Object?> get props => [message];
}

// --- Bloc ---
class AdminBloc extends Bloc<AdminEvent, AdminState> {
  final AdminRepository repository;
  final OrderRepository orderRepository;

  AdminBloc({required this.repository, required this.orderRepository})
    : super(AdminInitial()) {
    on<AdminLogin>(_onLogin);
    on<LoadAdminData>(_onLoadData);
    on<CloseRoomEvent>(_onCloseRoom);
    on<BroadcastMessageEvent>(_onBroadcast);
    on<BanUserEvent>(_onBanUser);
    on<UpdateOrderStatusEvent>(_onUpdateOrderStatus);
    on<AdminLogout>((_, emit) {
      emit(AdminInitial());
    });
  }

  Future<void> _onLogin(AdminLogin event, Emitter<AdminState> emit) async {
    emit(AdminLoading());
    try {
      final results = await Future.wait([
        repository.getStats(),
        repository.getRooms(),
        orderRepository.getAllOrders(),
      ]);
      final stats = results[0] as Map<String, dynamic>;
      final rooms = results[1] as List<dynamic>;
      final orders = results[2] as List<Order>;

      emit(AdminAuthenticated(stats: stats, rooms: rooms, orders: orders));
    } catch (e) {
      emit(AdminError("Authorization Failed. Error: $e"));
    }
  }

  Future<void> _onLoadData(
    LoadAdminData event,
    Emitter<AdminState> emit,
  ) async {
    if (state is! AdminAuthenticated) return;
    try {
      final results = await Future.wait([
        repository.getStats(),
        repository.getRooms(),
        orderRepository.getAllOrders(),
      ]);
      final stats = results[0] as Map<String, dynamic>;
      final rooms = results[1] as List<dynamic>;
      final orders = results[2] as List<Order>;

      emit(AdminAuthenticated(stats: stats, rooms: rooms, orders: orders));
    } catch (e) {
      emit(AdminError("Failed to refresh data: $e"));
    }
  }

  Future<void> _onUpdateOrderStatus(
    UpdateOrderStatusEvent event,
    Emitter<AdminState> emit,
  ) async {
    try {
      await orderRepository.updateOrderStatus(
        event.orderId,
        event.status,
        videoUrl: event.videoUrl,
      );
      add(LoadAdminData()); // Refresh list
    } catch (e) {
      emit(AdminError("Failed to update status: $e"));
    }
  }

  Future<void> _onCloseRoom(
    CloseRoomEvent event,
    Emitter<AdminState> emit,
  ) async {
    try {
      await repository.closeRoom(event.roomId);
      add(LoadAdminData()); // Refresh list
    } catch (e) {
      emit(AdminError("Failed to close room: $e"));
    }
  }

  Future<void> _onBroadcast(
    BroadcastMessageEvent event,
    Emitter<AdminState> emit,
  ) async {
    try {
      await repository.broadcastMessage(event.message);
      // No state change needed, maybe a success notification later
    } catch (e) {
      emit(AdminError("Broadcast failed: $e"));
    }
  }

  Future<void> _onBanUser(BanUserEvent event, Emitter<AdminState> emit) async {
    try {
      await repository.banUser(event.userId);
      add(
        LoadAdminData(),
      ); // Refresh list to see if they are gone/status changes
    } catch (e) {
      emit(AdminError("Ban failed: $e"));
    }
  }
}
